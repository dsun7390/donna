from django.apps import AppConfig


class SurveyTakerConfig(AppConfig):
    name = "surveytaker"
