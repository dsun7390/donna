from django.apps import AppConfig

class SurveybuilderConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'surveybuilder'
